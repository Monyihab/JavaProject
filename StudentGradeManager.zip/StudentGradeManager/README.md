# Student Grade Manager

A simple Java project that manages student grades.

## Structure

```
StudentGradeManager/
├── src/
│   └── com/grademanager/
│       ├── Main.java                  # Entry point
│       ├── model/
│       │   └── Student.java           # Student entity
│       ├── service/
│       │   └── GradeService.java      # Business logic
│       └── util/
│           └── GradeUtil.java         # Utility/formatting helpers
└── README.md
```

## How to Compile & Run

```bash
# From the project root
javac -d out $(find src -name "*.java")
java -cp out com.grademanager.Main
```

## Features
- Add students and assign grades
- Calculate individual averages and letter grades
- Find top student and class average

package com.grademanager;

import com.grademanager.model.Student;
import com.grademanager.service.GradeService;
import com.grademanager.util.GradeUtil;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        GradeService service = new GradeService();

        // Add students
        Student alice = service.addStudent("Alice Johnson");
        Student bob   = service.addStudent("Bob Smith");
        Student carol = service.addStudent("Carol White");

        // Add grades
        service.addGrade(alice.getId(), 92);
        service.addGrade(alice.getId(), 88);
        service.addGrade(alice.getId(), 95);

        service.addGrade(bob.getId(), 74);
        service.addGrade(bob.getId(), 68);
        service.addGrade(bob.getId(), 80);

        service.addGrade(carol.getId(), 55);
        service.addGrade(carol.getId(), 60);
        service.addGrade(carol.getId(), 58);

        // Print report
        GradeUtil.printHeader("STUDENT GRADE REPORT");

        List<Student> allStudents = service.getAllStudents();
        for (Student s : allStudents) {
            System.out.printf("%-20s | Avg: %s | Grade: %s%n",
                    s.getName(),
                    GradeUtil.formatGrade(s.getAverage()),
                    s.getLetterGrade());
        }

        GradeUtil.printSeparator();
        System.out.printf("Class Average : %s%n", GradeUtil.formatGrade(service.getClassAverage()));

        Student top = service.getTopStudent();
        if (top != null)
            System.out.printf("Top Student   : %s (%.2f)%n", top.getName(), top.getAverage());

        GradeUtil.printSeparator();
    }
}

package com.grademanager.service;

import com.grademanager.model.Student;

import java.util.*;

public class GradeService {
    private final Map<Integer, Student> students = new LinkedHashMap<>();
    private int nextId = 1;

    public Student addStudent(String name) {
        Student s = new Student(nextId++, name);
        students.put(s.getId(), s);
        return s;
    }

    public boolean addGrade(int studentId, double grade) {
        Student s = students.get(studentId);
        if (s == null) return false;
        s.addGrade(grade);
        return true;
    }

    public Optional<Student> findById(int id) {
        return Optional.ofNullable(students.get(id));
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(students.values());
    }

    public Student getTopStudent() {
        return students.values().stream()
                .max(Comparator.comparingDouble(Student::getAverage))
                .orElse(null);
    }

    public double getClassAverage() {
        return students.values().stream()
                .mapToDouble(Student::getAverage)
                .average()
                .orElse(0);
    }
}

package com.grademanager.util;

public class GradeUtil {

    public static void printSeparator() {
        System.out.println("=".repeat(50));
    }

    public static void printHeader(String title) {
        printSeparator();
        System.out.println("  " + title);
        printSeparator();
    }

    public static String formatGrade(double grade) {
        return String.format("%.2f", grade);
    }
}
